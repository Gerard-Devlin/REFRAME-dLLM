# FOCUS-v7 cache-producing prefix verifier

Research question: can a 64-row verification packet produce legal reusable KV
and the next proposal, so repeated large regular cache passes are unnecessary?
This is a bounded mechanism probe, not a deployed generator or achieved speedup.

The packet contains clean tracked rows, clean candidate MASK rows, ordered draft
sources and ordered MASK audits. Each query has exactly one version of every
candidate position. A draft source i sees draft identities <=i; audit i sees only
identities <i. Future positions use clean MASK sources; clean context never reads
speculative identities. Therefore rejected later identities cannot contaminate
the accepted prefix's source KV at any layer. Actual native Triton private K/V
buffers are captured and partially promoted into a private shadow bank.

Keep the verified prefix and, if possible, one argmax correction at the first
rejection. This correction has no matching input-identity KV and MUST be queried
as a changed identity in the next packet. Clean logits are at most proposals for
the next iteration, never direct commitments under the changed state. Static
external and clean future KV remain approximate: this is not native equivalence.
EOS and output handling must receive explicit treatment before free generation.

The useful difference to test is removing a repeated cache/proposal pass using
prefix-conditional KV already produced by verification, with bounded identity
repair. Prefix verification, correction tokens, tree masks and pipelining are
existing tools, not independent novelty claims. [FreeDave](https://arxiv.org/abs/2510.00294)
already pipelines drafting and verification; its pinned implementation expands
full states/branches and does not establish this packet's quality or cost.
No publishability claim follows from this source design.

## Predeclared mechanism gate

Six reused dev prompts (two each HumanEval/MBPP/MATH), two earliest eligible
official Flash windows with >=16 nonspecial proposals, K=8/16, gamma=.8. Official
Flash owns all online commits; shadows never alter public cache or output.
Compare ONLY newly produced packet prefix/correction to baseline regular-safe
tokens plus official accepted tokens. Do not credit baseline's preceding safe
commits to the packet. Original final canvas is retrospective reference, not gold.

Require one uniform K with >=24 produced tokens, >=.95 reference-token agreement,
no task below .90, and progress/cost ratio >=1.3 with every task >=1.0. Include
packet construction, capture, decisions and actual selected-KV copy cost. This
fixed-state condition is only a necessary screen: warm-up, bootstrap, stale
proposal acceptance, dirty repair and drain still require actual free generation.
No full generator if this screen fails. Reject if any public cache/output changes
or any real all-layer own/later-label perturbation changes a prefix audit/source.
