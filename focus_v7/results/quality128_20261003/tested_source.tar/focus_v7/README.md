# FOCUS-v7 cache-producing prefix verifier

Research question: can a 64-row verification packet produce legal reusable KV
and the next proposal, so repeated large regular cache passes are unnecessary?
This is a bounded mechanism probe, not a deployed generator or achieved speedup.

The packet contains clean tracked rows, clean candidate MASK rows, ordered draft
sources and ordered MASK audits. Each query has exactly one version of every
candidate position. A draft source i sees draft identities <=i; audit i sees only
identities <i. Future positions use clean MASK sources; clean context never reads
speculative identities. Therefore rejected later identities cannot contaminate
the accepted prefix's source KV at any layer. Actual native Triton private K/V
buffers are captured and partially promoted into a private shadow bank.

Keep the verified prefix and, if possible, one argmax correction at the first
rejection. This correction has no matching input-identity KV and MUST be queried
as a changed identity in the next packet. Clean logits are at most proposals for
the next iteration, never direct commitments under the changed state. Static
external and clean future KV remain approximate: this is not native equivalence.
EOS and output handling must receive explicit treatment before free generation.

The useful difference to test is removing a repeated cache/proposal pass using
prefix-conditional KV already produced by verification, with bounded identity
repair. Prefix verification, correction tokens, tree masks and pipelining are
existing tools, not independent novelty claims. [FreeDave](https://arxiv.org/abs/2510.00294)
already pipelines drafting and verification; its pinned implementation expands
full states/branches and does not establish this packet's quality or cost.
No publishability claim follows from this source design.

## Predeclared mechanism gate

Six reused dev prompts (two each HumanEval/MBPP/MATH), two earliest eligible
official Flash windows with >=16 nonspecial proposals, K=8/16, gamma=.8. Official
Flash owns all online commits; shadows never alter public cache or output.
Compare ONLY newly produced packet prefix/correction to baseline regular-safe
tokens plus official accepted tokens. Do not credit baseline's preceding safe
commits to the packet. Original final canvas is retrospective reference, not gold.

Require one uniform K with >=24 produced tokens, >=.95 reference-token agreement,
no task below .90, and progress/cost ratio >=1.3 with every task >=1.0. Include
packet construction, capture, decisions and actual selected-KV copy cost. This
fixed-state condition is only a necessary screen: warm-up, bootstrap, stale
proposal acceptance, dirty repair and drain still require actual free generation.
No full generator if this screen fails. Reject if any public cache/output changes
or any real all-layer own/later-label perturbation changes a prefix audit/source.

## Completed cumulative-budget packet: rejected (2026-10-03)

The guarded GPU1 run exited0, with11 server CPU tests, six unchanged official
response hashes, unchanged public KV, and SDPA0. Six actual32-layer label
perturbations preserved all legal audit logits and source K/V exactly. Native
private buffers were actually copied to a separate bank, with that cost included.

| K | Produced tokens | Reference-final matches | Median packet wall time | Fixed-state progress/cost vs Flash |
|---|---:|---:|---:|---:|
|8|23|22|26.94ms|0.524x|
|16|24|24|26.49ms|0.558x|

The reference is an official Flash final canvas, not ground truth; windows share
six dev prompts. No task accuracy or end-to-end speed result follows. Baseline
on these12states produced41regular-safe+54verified tokens; the packet produced
only12verified+12correction tokens at K16. Cost/progress, not source isolation,
failed. Do not expand THIS cumulative-.8 policy to free generation.

CPU follow-up separated token disagreement from cumulative-budget exhaustion:
K16 has8budget-only first failures and4argmax disagreements. Longest argmax-match
prefix plus correction would propose83tokens rather than24 on these same states.
Their reference agreement and selected-KV-copy cost were not measured. This is
evidence for a SEPARATE deterministic-match admission diagnostic, not permission
to relabel the failed predeclared gate as a success or call it lossless.

Additional close work: [SimSD](https://arxiv.org/html/2606.02544) explicitly uses
paired data/MASK copies, temporal masking, position alignment and prefix/rejection
correction. Those are prior mechanisms. Our clean future bank addresses all-layer
reachability at an acceptance cost; this fact alone is not a paper contribution.
[DFlow](https://arxiv.org/html/2609.06498) relays rejected verifier representations
into a trained diffusion drafter, so generic cross-round information reuse is
also prior art. Whether a no-training cache-producing packet is useful remains
an experimental question.

Original source is archived as `results/prefix_cache_20261003/tested_source.tar`,
alongside the unchanged manifest, diagnostic and server test log. CPU policy
analysis is separately named and does not rescore tasks.

## Completed deterministic-match packet (2026-10-03)

The separate K16 screen exited0. Actual selected-KV copy and decisions included:
83produced tokens,79matching Flash's eventual canvas (.9518), packet median
26.49ms. Fixed-state progress/cost was1.923x, with task ratios HE1.835/MBPP1.548/
MATH2.243. Reference agreement was HE1.0/MBPP.895/MATH.95. The predeclared .98
overall/.95per-task reference-agreement gate FAILED; original report is preserved.
Six actual all-layer controls still had zero audit/source-KV perturbation error,
six official outputs remained identical, and SDPA0. No achieved end-to-end speed
or task accuracy follows from these figures. Exact tested source and reports are
in `results/match_cache_20261003/`.

Because the user allows different/better answers, `GENERATION_PLAN.md` declares a
separate six-old-dev task-scored failure diagnosis. It does not relax or relabel
the failed screen. The prototype pays for its own bootstrap, dated proposal
refill, full clean identity repair, real KV transactions and final rendering.
Official execution/final-expression scoring and fixed-work controls decide
whether the local progress signal survives actual generation. No automatic
dataset expansion or success/novelty claim is permitted.

## Actual six-dev generation: not a successful candidate

The separate full-generation diagnosis exited0 with21server CPU tests. Both
paths paid initialization, current generation and rendering; they used identical
BF16 weights, compact head and original FP64 probability reduction. Original
Flash output hashes matched all six old reference outputs, with SDPA0 and all
protected main/scoring/third-party hashes unchanged. Dated cold proposals were
never committed without a current packet audit. Every changed identity entered
the next clean query; captured legal native K/V were actually installed.

| Task (2old dev prompts each) | Flash mean seconds | v7 mean seconds | Latency ratio | Flash correct | v7 correct |
|---|---:|---:|---:|---:|---:|
|HumanEval|0.9889|1.0332|0.957x|1/2|0/2|
|MBPP|0.7033|0.4485|1.568x|0/2|0/2|
|MATH|2.8936|1.4453|2.002x|0/2|0/2|

These are tiny reused development samples, not benchmark accuracy estimates.
Quality did not survive HE122: the prototype ignores k and uses a <=10 string
length test, while Flash's program passes the official tests. This is semantic
error, not an answer-extraction artifact. Other tasks having zero correct answers
for both methods supplies no evidence of quality preservation.

On the first prompt of each task, filling ALL256positions gave latency ratios
HE1.437x, MBPP1.273x, MATH2.059x. They support a local execution opportunity beyond
earlierEOS, but still use different trajectories and are not equivalent-work
mathematical computations or a uniform speed result. HE54 in natural generation
uses39model calls versus Flash16; cold proposals and altered conditioning/ordering
can consume the saved per-cycle work. Current evidence does not isolate one cause.

Do not expand this frozen prototype to a larger dataset or announce superiority.
Keep the cache+verify architecture question open, but separate cache freshness,
legal conditioning and admission before further algorithm claims. Common fused
statistics and the strongest saved optimized Flash runtime still need a unified
comparison for ANY future successful candidate; this diagnosis alone does not
establish superiority over that runtime or other strong baselines.

Immutable outputs, manifest,21test log, exact tested source and separate CPU
analysis live in `results/free_generation_20261003/`. Earlier failed probability
and token-agreement screens remain unchanged. All three GPU jobs have exited and
GPU1 is released. No original LLaDA/v1 reevaluation or main-table edit occurred.
